#! /usr/bin/python3

import os
import time
import json
from json import JSONEncoder
import base64
import logging
from ctypes import *
from logging.handlers import RotatingFileHandler
from ctypes import cdll
from collections import namedtuple
import ipaddress
import warnings
import random
from requests.packages.urllib3.exceptions import InsecureRequestWarning
libgvtap = cdll.LoadLibrary('/usr/lib/libuctvl.so')

#FOR  REST CALL
import urllib
from urllib.request import urlopen
import requests
from requests.auth import HTTPBasicAuth
from requests import ReadTimeout, ConnectTimeout, HTTPError, Timeout, ConnectionError

#import gc
#mem profiling - install psutil module with pip3 install
#import psutil
#profile_counter = 0

logger = ''
HTTP_TIMEOUT = (120, 4)
list = []
token_id = ''
statspwd = ''
auth = ''
start_bracket = '['
end_bracket = ']'
is_ipv6_address = False
url = ''
url2 = ''
#time_interval value comes from FM
time_interval = 300
IP_ADDR_SIZE = 64
MAX_SECURE_TUNNEL_STATUS_LEN = 64
MAX_SECURE_TUNNEL_STATUS_TIME_LEN = 64
ST_MAX_SESSION = 2
valid_prefiltering_stats = False
valid_precryption_stats = False
valid_secure_tunnel_status = False
agent_cntlr_attr = namedtuple('agent_cntlr_attr', ['NAME', 'IP'])

class mirror_stats_attr_t(Structure):
    _fields_ = [
        ('pkt',         c_uint64),
        ('bytes',       c_uint64),
        ('tun_pkt',     c_uint64),
        ('tun_bytes',   c_uint64),
        ('tun_err_pkt', c_uint64),
	('tun_err_bytes', c_uint64),
	('tun_drop_pkt', c_uint64),
	('tun_drop_bytes', c_uint64),
	('punt_pkt', c_uint64),
	('punt_bytes', c_uint64),
        ('rx_tun_err_pkt', c_uint64),
	('rx_tun_err_bytes', c_uint64),
        ('ipAddr',     c_char * IP_ADDR_SIZE),
    ]

class precryption_stats_t(Structure):
    _fields_ = [
        ('rx_bytes',      c_uint64),
        ('rx_pkts',       c_uint64),
        ('rx_drop_pkts',  c_uint64),
        ('rx_err_pkts',   c_uint64),
        ('tx_bytes',      c_uint64),
        ('tx_pkts',       c_uint64),
        ('tx_drop_pkts',  c_uint64),
        ('tx_err_pkts',   c_uint64),
        ('ipAddr',     c_char * IP_ADDR_SIZE),
    ]

class secure_session_status(Structure):
    _fields_ = [
        ('status_str',                             c_char * MAX_SECURE_TUNNEL_STATUS_LEN),
        ('last_update_time_str',                   c_char * MAX_SECURE_TUNNEL_STATUS_TIME_LEN),
        ('tls_session_init_counter',               c_uint64),
        ('tls_session_connected_counter',          c_uint64),
        ('tls_session_failed_counter',             c_uint64),
        ('tls_session_cert_veri_failed_counter',   c_uint64),
        ('secure_tunnel_enable_status_t',          c_uint),
    ]

class secure_tunnel_status_t(Structure):
    _fields_ = [
        ('ss', secure_session_status * ST_MAX_SESSION),
    ]


mirror_stats_attr = mirror_stats_attr_t()
precryption_stats = precryption_stats_t()
sts = secure_tunnel_status_t()

def logging_init():
        global logger
        log_file = '/var/log/uctv-stats.log'
        log_format = ('%(asctime)s %(levelname)s %(message)s')
        logging.basicConfig(
        level = logging.INFO,
        format = log_format,
        handlers = [RotatingFileHandler(log_file, maxBytes=2048000, backupCount=8)]
        )
        # initializing registration
        logger = logging.getLogger("mirror stats")
        logger.info("Logging initialized.")
        logger.info("Logging file for registration: %s.", log_file)
   
def mirror_stats_collection_init():
        logger = logging.getLogger("mirror stats")
        global list
        global valid_prefiltering_stats
        global valid_precryption_stats
        global mirror_stats_attr
        global valid_secure_tunnel_status
        ##Read mirror names from /var/lib/uctv/data/mirrors/
        path = '/var/lib/uctv/data/mirrors/'

        if list:
            host = list[0].IP
            host_s = host.encode('utf-8')
            host_t = c_char_p(host_s)
            mirror_stats_attr = mirror_stats_attr_t()
            dir_list = os.listdir(path)
            for name in dir_list:
                mirrorName_s = name.encode('utf-8')
                mirr_name_t = c_char_p(mirrorName_s)
                local_mirror_stats_attr = mirror_stats_attr_t()
                logger.info("collecting stats data %s", name)
                if(libgvtap.gvtap_mirror_stats(host_t.value, mirr_name_t.value, byref(local_mirror_stats_attr)) == 0):
                    valid_prefiltering_stats = True
                    mirror_stats_attr.pkt += local_mirror_stats_attr.pkt
                    mirror_stats_attr.bytes += local_mirror_stats_attr.bytes
                    mirror_stats_attr.tun_pkt+=local_mirror_stats_attr.tun_pkt
                    mirror_stats_attr.tun_bytes+=local_mirror_stats_attr.tun_bytes
                    mirror_stats_attr.tun_err_pkt+=local_mirror_stats_attr.tun_err_pkt
                    mirror_stats_attr.tun_err_bytes+=local_mirror_stats_attr.tun_err_bytes
                    mirror_stats_attr.tun_drop_pkt+=local_mirror_stats_attr.tun_drop_pkt
                    mirror_stats_attr.tun_drop_bytes+=local_mirror_stats_attr.tun_drop_bytes
                    mirror_stats_attr.punt_pkt+=local_mirror_stats_attr.punt_pkt
                    mirror_stats_attr.punt_bytes+=local_mirror_stats_attr.punt_bytes
                #logger.info("collecting precryption stats")
                if(libgvtap.gvtap_precryption_stats(host_t.value, mirr_name_t.value, byref(precryption_stats)) == 0):
                    valid_precryption_stats = True
                if (name.startswith('s')):
                    if(libgvtap.gvtap_secure_tunnel_status(host_t.value, mirr_name_t.value, byref(sts)) == 0):
                        valid_secure_tunnel_status = True

def validate_ip_address(ip_string):
        global logger
        logger = logging.getLogger("mirror stats")
        global is_ipv6_address
        try:
            ip_object = ipaddress.ip_address(ip_string)
            if type(ip_object) == ipaddress.IPv4Address:
                is_ipv6_address = False
            if type(ip_object) == ipaddress.IPv6Address:
                is_ipv6_address = True
        except ValueError:
            logger.error("The IP address %s is not valid", ip_string)
        return is_ipv6_address

def stats_thread():
        global logger
        global valid_prefiltering_stats
        global valid_precryption_stats
        global valid_secure_tunnel_status
        logger = logging.getLogger("mirror stats")
        global token_id
        global list
        global statspwd
        global auth
        global url
        global url2
        status_code = 404
        skip_iteration = False

        get_ip_list()

        mirror_stats_collection_init()

        if not ((valid_prefiltering_stats == True) or (valid_precryption_stats == True) or (valid_secure_tunnel_status == True)):
            logger.info("Error : No valid stats to send")
            return

        sdata = []

        if (valid_prefiltering_stats == True):
            stats1 = {'packets': mirror_stats_attr.pkt,
                      'bytes': mirror_stats_attr.bytes,
                      'tunPackets': mirror_stats_attr.tun_pkt,
                      'tunBytes': mirror_stats_attr.tun_bytes,
                      'tunErrors': mirror_stats_attr.tun_err_pkt,
                      'ipAddr':list[0].IP}
            sdata.append({'prefiltering':stats1})

        if (valid_precryption_stats == True):
            stats2 = {'rxBytes': precryption_stats.rx_bytes,
                      'rxPackets': precryption_stats.rx_pkts,
                      'rxDropped': precryption_stats.rx_drop_pkts,
                      'rxErrors': precryption_stats.rx_err_pkts,
                      'txBytes': precryption_stats.tx_bytes,
                      'txPackets': precryption_stats.tx_pkts,
                      'txDropped': precryption_stats.tx_drop_pkts,
                      'txErrors': precryption_stats.tx_err_pkts,
                      'ipAddr':list[0].IP}
            sdata.append({'precryption':stats2})

        if (valid_secure_tunnel_status == True):
            status1 = {"mirrorSecureTunnelStatus" if i == 1 else "precryptionSecureTunnelStatus":{
                            'enableStatus' : sts.ss[i].secure_tunnel_enable_status_t,
                            'tlsSessionStatus' : sts.ss[i].status_str.decode(),
                            'tlsSessionLastUpdateTime' : sts.ss[i].last_update_time_str.decode(),
                        }
                        for i in range(ST_MAX_SESSION)
                    }
            status1['ipAddr'] = list[0].IP
            sdata.append({'SecureTunnelStatus' :status1})

        valid_prefiltering_stats = False
        valid_precryption_stats = False
        valid_secure_tunnel_status = False

        if list:
            list_len = len(list)
            statspwd = list[list_len - 2].IP
            base64_bytes = statspwd.encode('utf-8')
            message_bytes = base64.b64decode(base64_bytes)
            pwd = message_bytes.decode('utf-8')
            auth=('statsuser', pwd)

            i = 0
            for i in range(list_len):
                str1 = list[i].NAME
                str2 = 'controllerIp'
                if str1 != str2:
                    continue

                # Generate Auth Token 
                authToken={'ttl':600, 'id':''}
                http_str = 'https://'
                port_str = ':9900'
                url_path = '/uctv/v1.0/'
                func = 'tokens'
                attempt = 1
                is_v6 = validate_ip_address(list[i].IP)
                if is_v6:
                    url = http_str + str(start_bracket) + list[i].IP + str(end_bracket) + port_str + url_path + func
                else:
                    url = http_str + list[i].IP + port_str + url_path + func
                headers = {"charset": "utf-8", "Content-Type": "application/json", "Connection": "close"}
                while attempt <= 1 :
                    try:
                        with warnings.catch_warnings():
                            warnings.simplefilter("ignore", category=InsecureRequestWarning)
                            r = requests.post(url, data=json.dumps(authToken), auth=auth, verify = False, timeout = HTTP_TIMEOUT, headers = headers)
                        status_code = r.status_code
                    except requests.exceptions.ConnectionError:
                        logger.error("Connection error occurred in generate_auth_token for Controller %s", list[i].IP)
                    except requests.exceptions.HTTPError:
                        logger.error("Connection error occurred in generate_auth_token for Controller %s", list[i].IP)
                    except Exception as error:
                        logger.error("Error %s occured in generate_auth_token for controller %s", str(error), list[i].IP)
                    finally:
                        if(status_code != 201):
                            logger.error("Controller %s returned %d in generate_auth_token", list[i].IP, status_code)
                            skip_iteration = True
                        else:
                            logger.info("Controller %s returned %d in generate_auth_token 201 ig, have added break here", list[i].IP, status_code)
                            skip_iteration = False
                            break
                    requests.session().close()
                    time.sleep(5)
                    attempt+=1

                if skip_iteration:
                    skip_iteration = False
                    continue
                func = 'sd'
                is_v6 = validate_ip_address(list[i].IP)
                if is_v6:
                    url2 = http_str + str(start_bracket) + list[i].IP + str(end_bracket) + port_str + url_path + func
                else:
                    url2 = http_str + list[i].IP + port_str + url_path + func
                headers = {"charset": "utf-8", "Content-Type": "application/json"}

                token_id = json.loads(r.text)['access']['token']['id']
                res = requests.Response()
                headers = {'Content-Type':'application/json', 'Authorization': 'token_id', "Connection": "close"}
                try:
                    with warnings.catch_warnings():
                        warnings.simplefilter("ignore", category=InsecureRequestWarning)
                        res = requests.post(url2, data=json.dumps(sdata), auth=(token_id, 'unused'), verify = False, timeout = HTTP_TIMEOUT, headers = headers)
                    status_code = res.status_code
                except requests.exceptions.ConnectionError:
                    logger.error("Connection error occurred while connecting to Controller %s", list[i].IP)
                except requests.exceptions.HTTPError:
                    logger.error("Connection error occurred while connecting to Controller %s", list[i].IP)
                except Exception as error:
                    logger.error("Error %s occured while connecting to controller %s", str(error), list[i].IP)
                # Error handling added
                # add code here if controller-1 is successfully receives data, dont send same data to controller-2, controller-3 ...
                # if controller-1 is down, try sending to controller-2
                # if controller-2 is down, try sending to controller-3
                finally:
                    if(res.status_code != 201):
                        logger.info("controller: %s is down, looking for other controller", list[i].IP)
                    else:
                        logger.info("mirror stats data successfully pushed to controller: %s", list[i].IP)
                        break
                requests.session().close()
        else:
            logger.info("agentCntlr_data file not present at agent side yet")

def get_ip_list():
        global list
        global agent_cntlr_attr
        agent_cntlr_attr = namedtuple('agent_cntlr_attr', ['NAME', 'IP'])
        if os.path.isfile("/var/lib/uctv/data/agentCntlr_data"):
            list.clear()
            with open("/var/lib/uctv/data/agentCntlr_data") as f:
                for line in f.readlines():
                    data = line.split()
                    Node = agent_cntlr_attr(NAME=data[0], IP=data[1])
                    list.append(Node)
                    data.clear()

def mirror_stats_fun():
        global time_interval
        #global profile_counter
        #mypid = os.getpid()
        while True:
            stats_thread()
            #gc.collect()
            #profile_counter = profile_counter + 1
            #if profile_counter%10 == 0:
	    #        logger.info("profile_counter:" + str(profile_counter) + "vms (mb): " + str(float(psutil.Process().memory_info().vms) / 1048576.0))
            #	    logger.info(psutil.Process(mypid).memory_info())
            time.sleep(time_interval)

def main():
        #sleep for random time 1-59 seconds
        random.seed(time.time())
        rand_sleep_time = random.randrange(59)
        logger.info("Random Sleep time: %d.", rand_sleep_time)
        time.sleep(rand_sleep_time)
        mirror_stats_fun()

if __name__ == '__main__':
        logging_init()
        main()
