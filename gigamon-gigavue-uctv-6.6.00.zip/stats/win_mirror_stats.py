#! /usr/bin/python3.9

import os
import json
import logging
import base64
from ctypes import *
from logging.handlers import RotatingFileHandler
import requests
from requests import ReadTimeout, ConnectTimeout, HTTPError, Timeout, ConnectionError
import ipaddress

logger = ''
cntlr_data = []
stats_data = []
host_ip = ''
HTTP_TIMEOUT = (120, 4)
IP_ADDR_SIZE = 64

class mirror_stats_attr_t(Structure):
    _fields_ = [
        ('pkt',         c_uint64),
        ('bytes',       c_uint64),
        ('tun_pkt',     c_uint64),
        ('tun_bytes',   c_uint64),
        ('tun_err_pkt', c_uint64),
        ('ipAddr',     c_char * IP_ADDR_SIZE),
    ]
mirror_stats_attr = mirror_stats_attr_t()

def mirror_stats_logging():
    global logger
    log_file = 'C:\\ProgramData\\Uctv\\mirror-stats.log'
    log_format = ('%(asctime)s %(levelname)s %(message)s')
    logging.basicConfig(
        level = logging.INFO,
        format = log_format,
        handlers = [RotatingFileHandler(log_file, maxBytes=2048000, backupCount=8)]
    )
    # initializing registration
    logger = logging.getLogger("mirror stats")
    logger.info("Logging initialized.")
    logger.info("Logging file for registration: %s.", log_file)

def validate_ip_address(ip_string):
        global logger
        logger = logging.getLogger("mirror stats")
        is_ipv6_address = -1
        try:
            ip_object = ipaddress.ip_address(ip_string)
            if type(ip_object) == ipaddress.IPv4Address:
                is_ipv6_address = False
            if type(ip_object) == ipaddress.IPv6Address:
                is_ipv6_address = True
        except ValueError:
            logger.error("The IP address %s is not valid", ip_string)
        return is_ipv6_address

def get_cntlr_data():
    global cntlr_data
    config_file = "C:\\ProgramData\\Uctv\\data\\agentCntlr_data"

    if os.path.isfile(config_file) and os.path.exists(config_file) and os.access(config_file, os.R_OK):
        try:
            with open(config_file, 'r') as f:
                for line in f.readlines():
                    cntlr_data.append(line.split())
        except Exception as error:
            logger.error("Error %s during file read, agentCntlr_data", str(error))
            cntlr_data = []
    else:
        logger.error("Unable to open the file agentCntlr_data")

    #for entry in cntlr_data:
    #    logger.info("Name = %s, IP = %s", entry[0], entry[1])

def get_stats_data():
    global cntlr_data
    global mirror
    global host_ip
    global stats_data
    data_file = "C:\\ProgramData\\Uctv\\data\\stats"

    if os.path.isfile(data_file) and os.path.exists(data_file) and os.access(data_file, os.R_OK):
        try:
            with open(data_file, 'r') as f:
                for line in f.readlines():
                    stats_data.append(c_uint64(int(line.strip().split(":")[1])))
        except Exception as error:
            logger.error("Error %s during file read, stats", str(error))
            stats_data = []
            return
    else:
        logger.error("Unable to open the stats file")
        return

    host_ip = cntlr_data[0][1]
    host_s = host_ip.encode('utf-8')
    #logger.info("Agent IP = %s", host_s)

    #libgvtap = WinDLL('C:\\ProgramData\\uctv\\libgvtap.dll')
    #libgvtap.gvtap_mirror_stats(host_t.value, mirror_name_t.value, byref(mirror_stats_attr))

    #Remove below code after WinDll changes
    mirror_stats_attr.pkt = stats_data[0]
    mirror_stats_attr.bytes = stats_data[1]
    mirror_stats_attr.tun_pkt = stats_data[2]
    mirror_stats_attr.tun_bytes = stats_data[3]
    mirror_stats_attr.tun_err_pkt = stats_data[4]
    mirror_stats_attr.ipAddr = host_s

    #logger.info("mirror_stats_attr.pkt = %d", mirror_stats_attr.pkt)
    #logger.info("mirror_stats_attr.bytes = %d", mirror_stats_attr.bytes)
    #logger.info("mirror_stats_attr.tun_pkt = %d", mirror_stats_attr.tun_pkt)
    #logger.info("mirror_stats_attr.tun_bytes = %d", mirror_stats_attr.tun_bytes)
    #logger.info("mirror_stats_attr.tun_err_pkt = %d", mirror_stats_attr.tun_err_pkt)
    #logger.info("mirror_stats_attr.ipAddr = %s", mirror_stats_attr.ipAddr)

def send_rest():
    global logger
    global cntlr_data
    global host_ip
    status_code = 404

    try:
        pwd = cntlr_data[-2][1]
        base64_bytes = pwd.encode('utf-8')
        message_bytes = base64.b64decode(base64_bytes)
        decrypt_pwd = message_bytes.decode('utf-8')
    except Exception as error:
        logger.error("Error %s occured in password decode", str(error))
        return

    for entry in cntlr_data:
        if entry[0] != 'controllerIp':
            continue
        else:
            cntlr_ip = entry[1]

        # Generate Auth Token 
        authToken={'ttl':600, 'id':''}
        is_v6 = validate_ip_address(cntlr_ip)
        if is_v6:
            url1 = 'https://' + '[' + cntlr_ip + ']' + ':9900' + '/uctv/v1.0/' + 'tokens'
        else:
            url1 = 'https://' + cntlr_ip + ':9900' + '/uctv/v1.0/' + 'tokens'

        headers = {"charset": "utf-8", "Content-Type": "application/json", "Connection": "close"}
        auth=('statsuser', decrypt_pwd)

        try:
            r = requests.post(url1, data=json.dumps(authToken), auth=auth, verify = False, timeout = HTTP_TIMEOUT, headers = headers)
            status_code = r.status_code
        except requests.exceptions.ConnectionError:
            logger.error("Connection error occurred in generate_auth_token for Controller %s", cntlr_ip)
        except requests.exceptions.HTTPError:
            logger.error("HTTP error occurred in generate_auth_token for Controller %s", cntlr_ip)
        except Exception as error:
            logger.error("Error %s occured in generate_auth_token for controller %s", str(error), cntlr_ip)
        finally:
            if(status_code != 201):
                logger.error("Controller %s returned %d in generate_auth_token", cntlr_ip, status_code)
                continue
            else:
                logger.info("Controller %s returned %d in generate_auth_token", cntlr_ip, status_code)

        # Send mirror stats to any one controller. 
        if is_v6:
            url2 = 'https://' + '[' + cntlr_ip + ']' + ':9900' + '/uctv/v1.0/' + 'sd'
        else:
            url2 = 'https://' + cntlr_ip + ':9900' + '/uctv/v1.0/' + 'sd'

        headers = {"charset": "utf-8", "Content-Type": "application/json"}
        sdata = {'packets': mirror_stats_attr.pkt,
                 'bytes': mirror_stats_attr.bytes,
                 'tunPackets': mirror_stats_attr.tun_pkt,
                 'tunBytes': mirror_stats_attr.tun_bytes,
                 'tunErrors': mirror_stats_attr.tun_err_pkt,
                 'ipAddr': host_ip}

        tk = json.loads(r.text)['access']['token']['id']
        token_id = str(tk);
        headers = {'Content-Type':'application/json', 'Authorization': 'token_id', 'Connection': 'close'}

        try:
            r = requests.post(url2, data=json.dumps(sdata), auth=(token_id, 'unused'), verify = False, timeout = HTTP_TIMEOUT, headers = headers)
            status_code = r.status_code
        except requests.exceptions.ConnectionError:
            logger.error("Connection error occurred in generate_auth_token for Controller %s", cntlr_ip)
        except requests.exceptions.HTTPError:
            logger.error("HTTP error occurred in generate_auth_token for Controller %s", cntlr_ip)
        except Exception as error:
            logger.error("Error %s occured in generate_auth_token for controller %s", str(error), cntlr_ip)
        finally:
            if(status_code != 201):
                logger.error("Mirror stats not sent to controller %s, status_code = %d", cntlr_ip, status_code)
                continue
            else:
                logger.info("mirror stats successfully sent to controller: %s", cntlr_ip)
                break

def send_mirror_stats():
    get_cntlr_data()
    if cntlr_data:
        get_stats_data()
        if stats_data:
            send_rest()

def main():
    mirror_stats_logging()
    send_mirror_stats()

if __name__ == '__main__':
    main()
