#! /usr/bin/python3.9

import urllib3
import urllib
from urllib.request import urlopen
import json
from collections import namedtuple
import subprocess
import requests
import time
import os
import base64
import sys, getopt
import ast
import platform
import netifaces as ni
import signal
import os.path
import logging
import ipaddress
import re
from os import path
from requests import ReadTimeout, ConnectTimeout, HTTPError, Timeout, ConnectionError

USER_DATA_FILE = '/etc/gigamon-cloud.conf'
HTTP_TIMEOUT = (10, 20)
baseStatusCode = 200
maxHeartbeatLoss = 1
cntlrProxyForward = False
cloud_platform = ''
is_rem_ipv6 = False
local_intf_conf = ''
is_ip_ver_mismatch = False
logger = logging.getLogger(__name__)

reg_config_template = {
    "groupName":"",
    "subGroupName":"",
    "auth":"",
    "remoteIP": "",
    "sourceIP": "",
    "remotePort": 0,
}

reg_data_template = {
    "groupName":"",
    "subGroupName":"",
    "ipv4Addresses":[],
    "ipv6Addresses":[],
    "platform":"",
    "version":""
}

def errorCode(status_code, errMsg):
    pass
#    if status_code == 200:
#       logger.info("CODE[200]: 'Success'\n")
#       logger.info("\nAPI Response:" + str(errMsg))
#
#    else:
#       logger.info("\nHTTP Error Code:" + str(status_code))

def is_valid_ipv4_addr(ipaddr):
    try:
        ip = ipaddress.ip_address(ipaddr)
        if type(ip) == ipaddress.IPv4Address:
            return True
    except ValueError:
        return False

def is_valid_ipv6_addr(ipaddr):
    try:
        ip = ipaddress.ip_address(ipaddr)
        if type(ip) == ipaddress.IPv6Address:
            return True
    except ValueError:
        return False

def get_ipv6_addr():
    iplist = []
    ip_s = 0

    #ip_t = ni.ifaddresses('ens3')
    #logger.debug(ip_t[ni.AF_INET6])

    interfaces = ni.interfaces()
    for interface in interfaces:
         if interface:
             ip_s = ni.ifaddresses(interface)[ni.AF_INET6][0]['addr']
         if interface == 'lo' or not ip_s:
             continue
         else:
             iplist = [ip_s]
             return ip_s
    return ''

def get_valid_scope_ipv6_addr():
    cmd = "ip -6 addr | awk '/inet6 / && /global/ && !/deprecated/ && !/temporary/ && !/stable-privacy/ {print $2}\' | cut -d'/' -f 1"
    ip6_output = subprocess.check_output(cmd, shell=True)
    if ip6_output:
        ip6_buf = ip6_output.splitlines()
        if ip6_buf:
            ip6_str = ip6_buf[0].decode('ascii')
            logger.debug('IPv6 address from Intf: ' + ip6_str)
            return ip6_str

    return ''

def get_valid_scope_ipv6_addr_iface(iface_name):
    cmd = "ip -6 addr show dev " + iface_name + " | awk '/inet6 / && /global/ && !/deprecated/ && !/temporary/ && !/stable-privacy/ {print $2}' | cut -d'/' -f 1"
    ip6_output = subprocess.check_output(cmd, shell=True)
    if ip6_output:
        ip6_buf = ip6_output.splitlines()
        if ip6_buf:
            ip6_str = ip6_buf[0].decode('ascii')
            logger.debug('IPv6 address from Intf: ' + ip6_str)
            return ip6_str

    return ''

def get_instance_os():
    return platform.system()

def is_aws_instance():
    global cloud_platform
    if cloud_platform and cloud_platform == 'aws':
       return True

    """ for windows, it should have been detected by gvtapd.exe"""
    if get_instance_os() == 'Windows':
        return False

    """Check if an instance is running on AWS."""
    result = False
    output = subprocess.check_output('sudo /usr/sbin/dmidecode -t system', shell=True)
    output = output.decode('ascii')
    if output.find('mazon') != -1:
        cloud_platform = 'aws'
        result = True
    return result

def is_openstack_instance():
    global cloud_platform
    if cloud_platform and cloud_platform == 'openStack':
       return True

    """ for windows, it should have been detected by gvtapd.exe"""
    if get_instance_os() == 'Windows':
        return False

    """Check if an instance is running on Openstack."""
    result = False
    output = subprocess.check_output('sudo /usr/sbin/dmidecode -s system-product-name', shell=True)
    output = output.decode('ascii')
    if output.find('OpenStack') != -1:
        cloud_platform = 'openStack'
        result = True
    return result

def is_azure_instance():
    global cloud_platform
    if cloud_platform and cloud_platform == 'azure':
        return True

    """ for windows, it should have been detected by gvtapd.exe"""
    if get_instance_os() == 'Windows':
        return False

    """Check if an instance is running on Azure."""
    result = False
    output = subprocess.check_output('sudo /usr/sbin/dmidecode -s system-manufacturer', shell=True)
    output = output.decode('ascii')
    if output.find('Microsoft') != -1:
        cloud_platform = 'azure'
        result = True
    return result

def is_gcp_instance():
    global cloud_platform
    if cloud_platform and cloud_platform == 'gcp':
        return True

    """ for windows, it should have been detected by gvtapd.exe"""
    if get_instance_os() == 'Windows':
        return False

    """Check if an instance is running on GCP."""
    result = False
    output = subprocess.check_output('sudo /usr/sbin/dmidecode -s system-manufacturer', shell=True)
    output = output.decode('ascii')
    if output.find('Google') != -1:
        cloud_platform = 'gcp'
        result = True
    return result

def is_nutanix_instance():
    global cloud_platform
    if cloud_platform and cloud_platform == 'nutanix':
        return True

    """ for windows, it should have been detected by gvtapd.exe"""
    if get_instance_os() == 'Windows':
        return False

    """Check if an instance is running on Nutanix."""
    result = False
    output = subprocess.check_output('sudo /usr/sbin/dmidecode -s system-manufacturer', shell=True)
    output = output.decode('ascii')
    if output.find('Nutanix') != -1:
        cloud_platform = 'nutanix'
        result = True
    return result

def is_exsi_instance():
    global cloud_platform
    if cloud_platform and cloud_platform == 'vmware':
        return True

    """ for windows, it should have been detected by gvtapd.exe"""
    if get_instance_os() == 'Windows':
        return False

    """Check if an instance is running on VMware."""
    result = False
    output = subprocess.check_output('sudo /usr/sbin/dmidecode -s system-manufacturer', shell=True)
    output = output.decode('ascii')
    if output.find('VMware') != -1:
        cloud_platform = 'vmware'
        result = True
    return result

# Get AWS instance meta data and user data
def aws_get_meta_user_data(url):
    user_data = ''
    headers = {'X-aws-ec2-metadata-token-ttl-seconds': '21600'}
    try:
        resp = requests.put('http://169.254.169.254/latest/api/token', headers = headers, timeout=5)
        if resp.ok:
            token = resp.text
            headers = {'X-aws-ec2-metadata-token': token}
            resp = requests.get(url, headers = headers)
        else:
            resp = requests.get(url)
        if resp.ok:
            user_data = resp.text
    except requests.exceptions.RequestException as e:
        logger.error(str(e))

    return user_data

# Get OpenStack instance meta data and user data
def ops_get_meta_user_data(url):
    user_data = ''
    try:
        resp = requests.get(url, timeout=5)
        if resp.ok:
            user_data = resp.text
    except requests.exceptions.RequestException as e:
        logger.error(str(e))

    return user_data

# Get Azure instance meta data and user data
def azure_get_meta_user_data(url):
    user_data = ''
    headers = {'Metadata': 'true'}
    params = (('api-version', '2021-10-01'), ('format', 'text'))

    try:
        resp = requests.get(url, headers=headers, params=params, timeout=5)
        if resp.ok:
            user_data = resp.text

    except requests.exceptions.RequestException as e:
        logger.error(str(e))

    return user_data

# Get Gcp instance meta data and user data
def gcp_get_meta_user_data(url):
    user_data = ''
    headers = {'Metadata-Flavor': 'Google'}

    try:
        resp = requests.get(url, headers=headers,timeout=5)
        if resp.ok:
            user_data = resp.text

    except requests.exceptions.RequestException as e:
        logger.error(str(e))

    return user_data

# This function adds input drop rule to IP filter table, it's equivalent to shell command
#   $ /sbin/iptables -A INPUT -p tcp --dport 8891 -j DROP
#
def cntlr_drop_agent_request():
    import iptc
    logger.warning("Controller registration forwarding is OFF.")
    table = iptc.Table(iptc.Table.FILTER)
    table.autocommit = False
    chain = iptc.Chain(table, 'INPUT')
    for rule in chain.rules:
        if rule.protocol != 'tcp':
            continue
        for match in rule.matches:
            if match.dport == '8891':
                return
    rule = iptc.Rule()
    rule.protocol = 'tcp'
    target = rule.create_target("DROP")
    match = rule.create_match('tcp')
    match.dport = '8891'
    try:
        chain.insert_rule(rule)
    except Exception as e:
        logger.error(e)

    logger.info('FWD OFF: IP4 table dump: ')
    logger.info(iptc.easy.dump_chain('filter', 'INPUT', ipv6=False))
    table.refresh()
    table.commit()
    table.refresh()

# This function deletes input drop rule from IP filter table, it's equivalent to shell command
#   $ /sbin/iptables -D INPUT -p tcp --dport 8891 -j DROP
#
def cntlr_forward_agent_request():
    import iptc
    logger.info("Controller registration forwarding is ON.")
    table = iptc.Table(iptc.Table.FILTER)
    table.autocommit = False
    chain = iptc.Chain(table, 'INPUT')
    for rule in chain.rules:
        if rule.protocol != 'tcp':
            continue
        for match in rule.matches:
            if match.dport == '8891':
                try:
                    chain.delete_rule(rule)
                except Exception as e:
                    logger.error(e)
                finally:
                    break

    logger.info('FWD ON: IP4 table dump: ')
    logger.info(iptc.easy.dump_chain('filter', 'INPUT', ipv6=False))
    table.commit()
    table.refresh()

# This function adds input drop rule to IP filter table, it's equivalent to shell command
#   $ /sbin/ip6tables -A INPUT -p tcp --dport 8891 -j DROP
#
def cntlr_drop_agent_request_v6():
    import iptc
    logger.warning("Controller registration forwarding is OFF.")
    table6 = iptc.Table6(iptc.Table6.FILTER)
    table6.autocommit = False
    chain = iptc.Chain(table6, 'INPUT')
    for rule in chain.rules:
        if rule.protocol != 'tcp':
            continue
        for match in rule.matches:
            if match.dport == '8891':
                return
    rule = iptc.Rule6()
    rule.protocol = 'tcp'
    target = rule.create_target("DROP")
    match = rule.create_match('tcp')
    match.dport = '8891'
    try:
        chain.insert_rule(rule)
    except Exception as e:
        logger.error(e)

    logger.info('FWD OFF: IP6 table dump: ')
    logger.info(iptc.easy.dump_chain('filter', 'INPUT', ipv6=True))
    table6.refresh()
    table6.commit()
    table6.refresh()

# This function deletes input drop rule from IP filter table, it's equivalent to shell command
#   $ /sbin/iptables -D INPUT -p tcp --dport 8891 -j DROP
#
def cntlr_forward_agent_request_v6():
    import iptc
    logger.info("Controller registration forwarding is ON.")
    table6 = iptc.Table6(iptc.Table6.FILTER)
    table6.autocommit = False
    chain = iptc.Chain(table6, 'INPUT')
    for rule in chain.rules:
        if rule.protocol != 'tcp':
            continue
        for match in rule.matches:
            if match.dport == '8891':
                try:
                    chain.delete_rule(rule)
                except Exception as e:
                    logger.error(e)
                finally:
                    break

    logger.info('FWD ON: IP6 table dump: ')
    logger.info(iptc.easy.dump_chain('filter', 'INPUT', ipv6=True))
    table6.commit()
    table6.refresh()

def cntlr_reset_rest_server_admin_password():
    # on GvTAP controller REST server, only action from 127.0.0.1 is allowed
    global is_rem_ipv6
    resp_code = 0
    resp_data = ''
    try:
        if is_rem_ipv6:
            url = 'https://[::1]:9900/uctv/v1.0/users/admin/password'
        else:
            url = 'https://127.0.0.1:9900/uctv/v1.0/users/admin/password'
        r = requests.delete(url, verify = False, timeout = HTTP_TIMEOUT)
        resp_code = r.status_code
        resp_data = r.content
    except Exception as error:
        logger.error(str(error))
    finally:
        logger.info('Reset admin password [' + str(resp_code) +']')

class CatchTerm:
    term_now = False

    def __init__(self):
        #if get_instance_os() != 'Windows':
        signal.signal(signal.SIGTERM, self.exit_gracefully)
        signal.signal(signal.SIGINT, self.exit_gracefully)

    def exit_gracefully(self, signum, frame):
        self.term_now = True

class RegNode:
    def __init__(self, node_info):
        self.newHeartbeatFreq = None
        self.reg_info = {}
        is_ipv6 = -1
        for key in node_info:
            self.reg_info[key] = node_info[key]
        self.baseUrl = '/api/v1.3/cloud/orchestration/%s/registration' %node_info['entityType']
        if not 'remoteIP' in self.reg_info:
            return
        ips = self.reg_info['remoteIP']

        if is_valid_ipv6_addr(ips[0]):
            is_ipv6 = 1
        elif is_valid_ipv4_addr(ips[0]):
            is_ipv6 = 0

        if node_info['entityType'] == 'uctV':
            if is_ipv6:
                self.url = 'http://'+'[' + str(ips[0]) + ']' + ":" + self.reg_info['remotePort']
            else:
                self.url = 'http://'+str(ips[0]) + ":" + self.reg_info['remotePort']
        else:
            if is_ipv6:
                self.url = 'https://'+ '[' + str(ips[0]) + ']' + ":" + self.reg_info['remotePort']
            else:
                self.url = 'https://'+str(ips[0]) + ":" + self.reg_info['remotePort']
        self.state = "unregistered"

    def rotate_remote_ip(self):
        logger.debug("Rotate remote IP.")
        ips = self.reg_info['remoteIP']
        logger.debug("original %s", str(ips))
        if len(ips) <= 1:
            return
        ip = ips.pop(0)
        ips.append(ip)
        logger.debug("new %s", str(ips))
        if self.reg_info['entityType'] == 'uctV':
            if is_rem_ipv6:
                self.url = 'http://'+'[' + str(ips[0]) + ']' + ":" + self.reg_info['remotePort']
            else:
                self.url = 'http://'+str(ips[0]) + ":" + self.reg_info['remotePort']
        else:
            if is_rem_ipv6:
                self.url = 'https://'+ '[' + str(ips[0]) + ']' + ":" + self.reg_info['remotePort']
            else:
                self.url = 'https://'+str(ips[0]) + ":" + self.reg_info['remotePort']

    def Register(self):
        global reg_data_template
        global cntlrProxyForward
        global is_rem_ipv6

        if self.reg_info['entityType'] == 'uctVController':
            cntlr_reset_rest_server_admin_password()

        reg_data = dict(reg_data_template)
        for key in reg_data:
            reg_data[key] = self.reg_info[key]

        sendData = json.dumps(reg_data)
        logger.info('POST ' + self.url + self.baseUrl)
        start_time = time.time()
        resp_code = 0
        resp_data = ''
        try:
            headers = { "Authorization": self.reg_info['auth'] }
            logger.debug('sendData = ' + sendData)
            r = requests.post(self.url + self.baseUrl, data = sendData, verify = False, timeout = HTTP_TIMEOUT, headers = headers)
            resp_code = r.status_code
            resp_data = r.content
        except requests.exceptions.ConnectionError:
            logger.error("Connection error occurred.")
        except requests.exceptions.HTTPError:
            logger.error("HTTP error occurred.")
        except Exception as error:
            logger.error(str(error))
        finally:
            end_time = time.time()
            logger.debug("Elapsed time for registration in seconds: " + str(end_time - start_time));

            if resp_code == baseStatusCode:
                decoded_data = resp_data.decode('utf-8')
                response_dict = json.loads(decoded_data)
                logger.info('[' + str(resp_code) + '] ' + str(response_dict))
                key = 'id'
                if key in response_dict:
                    self.reg_info['id'] = response_dict['id']
                    self.state = "registered"
                    # once controller registered, starts to forward agent request
                    if self.reg_info['entityType'] == 'uctVController':
                        cntlr_forward_agent_request_v6()
                        cntlr_forward_agent_request()
                        cntlrProxyForward = True
                key = 'heartbeatFreqInSecs'
                if key in response_dict:
                    self.newHeartbeatFreq = response_dict[key]
            elif resp_code != 0:
                logger.info('[' + str(resp_code) + '] ' + str(resp_data) if (resp_data) else '')
                errorCode(resp_code, resp_data)
                self.state = "unregistered"
            else: # in case failure, switch to different remote IP
               self.rotate_remote_ip()

class NodeInfo:
    def __init__(self, reg_info_file, n_info):
        self.reg_info_file = reg_info_file
        self.node_info = {}
        self.set_node_info(n_info)

    def set_heartbeat_freq(self, freq):
        self.node_info['heartbeatFreqInSecs'] = int(freq)

    def set_node_info(self, n_info):
        global is_rem_ipv6
        global local_intf_conf
        global is_ip_ver_mismatch
        src_ip = []
        is_src_ipv6 = False
        err_ipv6 = False

        self.load_reg_info(n_info)
        if 'remoteIP' in self.node_info:
            rem_ip = self.node_info['remoteIP']
            if rem_ip:
                if is_valid_ipv6_addr(rem_ip[0]):
                    is_rem_ipv6 = True
                elif is_valid_ipv4_addr(rem_ip[0]):
                    is_rem_ipv6 = False
                logger.info("Remote IP : " + rem_ip[0] + " is_rem_IPv6 = " + str(is_rem_ipv6))

        if 'sourceIP' in self.node_info:
            src_ip = self.node_info['sourceIP']

        if src_ip:
            ips = []
            if is_valid_ipv6_addr(src_ip[0]):
                is_src_ipv6 = True
            elif is_valid_ipv4_addr(src_ip[0]):
                is_src_ipv6 = False

            logger.info("Source IP from conf = " + str(src_ip[0]) + " IP ver = " + str(is_src_ipv6))
            if is_rem_ipv6 != is_src_ipv6:
                is_ip_ver_mismatch = True
            ips = src_ip
        else:
            if n_info['entityType'] == 'uctVController':
                ips = []
                if is_aws_instance():
                    if is_rem_ipv6:
                        ip = get_valid_scope_ipv6_addr()
                        if not ip:
                            err_ipv6 = True
                    else:
                        ip = aws_get_meta_user_data("http://169.254.169.254/latest/meta-data/public-ipv4")
                    if not ip:
                        if not is_rem_ipv6:
                            ip = aws_get_meta_user_data("http://169.254.169.254/latest/meta-data/local-ipv4")
                    if ip:
                        ips = [ip]
                elif is_openstack_instance():
                    if is_rem_ipv6:
                        ip = get_valid_scope_ipv6_addr()
                        if not ip:
                            err_ipv6 = True
                    else:
                        ip = ops_get_meta_user_data("http://169.254.169.254/latest/meta-data/public-ipv4")
                    if not ip:
                        if not is_rem_ipv6:
                            ip = ops_get_meta_user_data("http://169.254.169.254/latest/meta-data/local-ipv4")
                    if ip:
                        ips = [ip]
                elif is_azure_instance():
                     logger.info("UCT-V: fetch ip for azure instance")
                     if is_rem_ipv6:
                         ip = get_valid_scope_ipv6_addr()
                         if not ip:
                             err_ipv6 = True
                     else:
                         ip = azure_get_meta_user_data("http://169.254.169.254/metadata/instance/network/interface/0/ipv4/ipAddress/0/publicIpAddress")
                     if not ip:
                         if not is_rem_ipv6:
                             ip = azure_get_meta_user_data("http://169.254.169.254/metadata/instance/network/interface/0/ipv4/ipAddress/0/privateIpAddress")
                     if ip:
                        ips = [ip]
                elif is_gcp_instance():
                    logger.info("UCT-V: fetch ip for GCP controller instance")
                    if is_rem_ipv6:
                        ip = get_valid_scope_ipv6_addr()
                        if not ip:
                            err_ipv6 = True
                    else:
                        ip = gcp_get_meta_user_data("http://169.254.169.254/computeMetadata/v1/instance/network-interfaces/0/access-configs/0/external-ip")
                    if not ip:
                        if not is_rem_ipv6:
                            ip = gcp_get_meta_user_data("http://169.254.169.254/computeMetadata/v1/instance/network-interfaces/0/ip")
                    if ip:
                        ips = [ip]
                else:
                    pass
                '''
                    interfaces = ni.interfaces()
                    for interface in interfaces:
                        ip = ni.ifaddresses(interface)[ni.AF_INET][0]['addr']
                        if interface == 'lo' or not ip:
                            continue
                        else:
                            ips = [ip]
                            break
                '''
            else:
                ips = []
                if is_aws_instance():
                    if is_rem_ipv6:
                        if get_instance_os() != 'Windows':
                            ip = get_valid_scope_ipv6_addr()
                        else:
                            ip = self.get_windows_valid_scope_ipv6_address()
                        if not ip:
                            err_ipv6 = True
                    else:
                        ip = aws_get_meta_user_data("http://169.254.169.254/latest/meta-data/local-ipv4")
                    if ip:
                        ips = [ip]
                elif is_openstack_instance():
                    if is_rem_ipv6:
                        if get_instance_os() != 'Windows':
                            ip = get_valid_scope_ipv6_addr()
                        else:
                            ip = self.get_windows_valid_scope_ipv6_address()
                        if not ip:
                            err_ipv6 = True
                    else:
                        ip = ops_get_meta_user_data("http://169.254.169.254/latest/meta-data/local-ipv4")
                    if ip:
                        ips = [ip]
                elif is_gcp_instance():
                    logger.info("UCT-V: fetch ip for gcp agent instance")
                    if is_rem_ipv6:
                        if get_instance_os() != 'Windows':
                            ip = get_valid_scope_ipv6_addr()
                        else:
                            ip = self.get_windows_valid_scope_ipv6_address()
                        if not ip:
                            err_ipv6 = True
                    else:
                        ip = gcp_get_meta_user_data("http://169.254.169.254/computeMetadata/v1/instance/network-interfaces/0/ip")
                    if ip:
                        ips = [ip]
                elif is_azure_instance():
                    logger.info("UCT-V: fetch private ip for azure instance")
                    if is_rem_ipv6:
                        if get_instance_os() != 'Windows':
                            ip = get_valid_scope_ipv6_addr()
                        else:
                            ip = self.get_windows_valid_scope_ipv6_address()
                        if not ip:
                            err_ipv6 = True
                    else:
                        ip = azure_get_meta_user_data("http://169.254.169.254/metadata/instance/network/interface/0/ipv4/ipAddress/0/privateIpAddress")
                    if ip:
                        ips = [ip]
                        logger.debug("Agent Source IP = " + str(ips))
                else:
                    if is_rem_ipv6:
                        if get_instance_os() != 'Windows':
                            ip = get_valid_scope_ipv6_addr()
                        else:
                            ip = self.get_windows_valid_scope_ipv6_address()
                        if not ip:
                            err_ipv6 = True

                        if ip:
                            ips = [ip]
                            logger.debug("Interface: Agent Source IPv6 Addr = " + str(ips))
                    else:
                        interfaces = ni.interfaces()
                        for interface in interfaces:
                            ip = ni.ifaddresses(interface)[ni.AF_INET][0]['addr']
                            if interface == 'lo' or not ip:
                                continue
                            else:
                                ips = [ip]
                                logger.debug("Interface: Agent Source IP = " + str([ip]))
                                break
        if ips:
            if is_rem_ipv6:
               self.node_info['ipv6Addresses'] = ips
               self.node_info['ipv4Addresses'] = []
            else:
               self.node_info['ipv4Addresses'] = ips
               self.node_info['ipv6Addresses'] = []
        else:
            if is_rem_ipv6 and err_ipv6:
                logger.error("Couldn't able to fetch Source IPv6 address from the interface")
            self.node_info['ipv4Addresses'] = []
            self.node_info['ipv6Addresses'] = []

        if is_rem_ipv6:
            logger.info("UCT-V: IPv6 used for comm is %s", self.node_info['ipv6Addresses'])
        else:
            logger.info("UCT-V: IPv4 used for comm is %s", self.node_info['ipv4Addresses'])
        # populate default user name, password, remote port
        if n_info['entityType'] == 'uctVController':
            self.node_info['remotePort'] = '443'
        else:
            self.node_info['remotePort'] = '8891'

        if local_intf_conf:
            if get_instance_os() != 'Windows':
                if is_rem_ipv6:
                    ip = get_valid_scope_ipv6_addr_iface(local_intf_conf)
                else:
                    ip = ni.ifaddresses(local_intf_conf)[ni.AF_INET][0]['addr']
            else:
                logger.info("windows..")
                if is_rem_ipv6:
                    ip = self.get_windows_valid_scope_ipv6_iface(local_intf_conf)
                else:
                    ip = self.get_windows_ip(local_intf_conf)
            logger.info("Interface:" + local_intf_conf +" ip:" + ip)
            if ip:
                if is_rem_ipv6:
                    self.node_info['ipv6Addresses'] = [ip]
                    logger.info("Overriding IPv6:" + ip)
                else:
                    self.node_info['ipv4Addresses'] = [ip]
                    logger.info("Overriding IPv4:" + ip)

        ## Merge the two sets ##
        self.node_info.update(n_info)

        if n_info['entityType'] == 'uctV' and get_instance_os() == 'Windows':
             logger.info("set adapter property for agent")
             command = 'Set-NetAdapterAdvancedProperty -DisplayName "Send Buffer Size" -DisplayValue 128MB'
             subprocess.run(["powershell", "-Command", command])

    def get_windows_ip(self, ifname):
        from scapy.all import get_if_list
        from scapy.all import IFACES
        l=get_if_list()
        dict=IFACES.data
        #logger.info(dict)
        ip = ""

        logger.info("==============================")
        for item in l:
            logger.info(dict[item].name + " : " + dict[item].ip)
            name = dict[item].name
            if ifname == name.replace(" ",""):
                ip = dict[item].ip
        logger.info("==============================")
        return ip

    def get_windows_valid_scope_ipv6_address(self):
        output = subprocess.check_output("ipconfig", encoding='utf-8')

        interfaces = re.split(r'\n(?=[^\s])', output)

        ipv6_pattern = r"IPv6 Address[ .]*: ([0-9a-fA-F:]+)"
        for interface in interfaces:
            ipv6_match = re.search(ipv6_pattern, interface)
            if ipv6_match:
                ipv6_address = ipv6_match.group(1)
                if not ipv6_address.lower().startswith('fe80'):
                    return ipv6_address

        return None

    def get_windows_valid_scope_ipv6_iface(self, intf_name):
        output = subprocess.check_output("ipconfig", encoding='utf-8')

        intf_pattern = re.escape(intf_name) + r"[\s\S]*?(?=^\S|\Z)"
        if output:
            intf_output = re.search(intf_pattern, output, re.MULTILINE)

        if not intf_output:
            return None

        ipv6_pattern = r"IPv6 Address[ .]*: ([0-9a-fA-F:]+)"
        ipv6_match = re.search(ipv6_pattern, intf_output.group())

        if ipv6_match:
            return ipv6_match.group(1)
        else:
            return None

    def load_reg_info(self, n_info):
        s = ''
        global cloud_platform
        global local_intf_conf

        if path.exists(self.reg_info_file):
            logger.info("Load user data from config file")
            file = open(self.reg_info_file,  mode='r')
            if file:
                s = file.read()

        if not s:
            logger.info("Orchestration configuration not found.")
            return

        s = str(s)

        s_lines = s.split('\n')

        if s_lines[0] != "Registration:":
            logger.info("Registration configuration is Incorrect.")
            return

        start = s.find("Registration:\n") + len("Registration:\n")
        end = s.find("\n\n", len("Registration:"))
        if end == -1:
            end = len(s)
        substring = s[start:end]
        lines = substring.split("\n")
        for line in lines:
            name, var = line.partition(":")[::2]
            name = name.strip()
            var = var.strip().split('\t')

            if name == 'localInterface' and n_info['entityType'] == 'uctV':
                local_intf_conf = var[0]
                """
                if get_instance_os() != 'Windows':
                    ip = ni.ifaddresses(var[0])[ni.AF_INET][0]['addr']
                else:
                    logger.info("windows..")
                    ip = self.get_windows_ip(var[0])
                logger.info("Interface:" + var[0] +" ip:" + ip)
                if ip:
                    self.node_info['ipv4Addresses'] = [ip]
                    logger.info("Overriding IPv4:" + ip)
                """
            elif name == 'remoteIP':
                # split multiple ips
                ips = var[0].split(',')
                self.node_info['remoteIP'] = ips
            elif name == 'sourceIP':
                # split multiple ips
                c_ips = var[0].split(',')
                self.node_info['sourceIP'] = c_ips
            else:
                self.node_info[name.strip()] = var[0]

        self.node_info['platform'] = cloud_platform

        if 'user' in self.node_info and 'password' in self.node_info:
            # Encode user and password in the conf file
            usrPass = self.node_info['user'] + ':' + self.node_info['password']
            usrPass = bytearray(usrPass, 'utf-8')
            b64Val = base64.b64encode(usrPass)
            auth = "Basic %s" % b64Val.decode('utf-8')
            if get_instance_os() == 'Windows':
                self.node_info['auth'] = auth
                authtxt = "auth: " + auth
                with open('C:/ProgramData/uctv/gigamon-cloud.conf', 'r') as fread:
                    linesread = fread.readlines()
                with open('C:/ProgramData/uctv/gigamon-cloud.conf', 'w') as fwrite:
                    for line in linesread:
                        if "user:" not in line.strip("\n") and "password:" not in line.strip("\n") :
                            if "subGroupName:" in line.strip("\n"):
                                line+="      "+authtxt+"\n"
                            fwrite.write(line)
            else:
                self.node_info.pop('user', None)
                self.node_info.pop('password', None)
                self.node_info['auth'] = auth
                os.system("sed -i '/user:/d' " + USER_DATA_FILE)
                os.system("sed -i 's/password:.*/auth: " + auth + "/' " + USER_DATA_FILE)
        elif not 'auth' in self.node_info:
            logger.error("Missing auth data in cloud config file")

def main(argv):
   node_version = ''
   entity_type = ''
   platform = ''
   urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
   try:
       opts, args = getopt.getopt(argv,"hv:t:p:",["version=", "entity-type=", "platform="])
   except getopt.GetoptError:
      logger.info ('regheartbeat_main.py -v <node version> -t <entity-type>')
      sys.exit(2)
   for opt, arg in opts:
      if opt == '-h':
         logger.info ('regheartbeat_main.py -v <node version> -t <entity-type>')
         sys.exit()
      elif opt in ("-v", "--version"):
         node_version = arg
      elif opt in ("-t", "--entity-type"):
         entity_type = arg
      elif opt in ("-p", "--platform"):
         platform = arg
   return node_version, entity_type, platform

class RegHeartBeat:
    def __init__(self, version, entity_type, platform_in):
        global cloud_platform
        global cntlrProxyForward
        self.running = True
        self.version = version
        self.entity_type = entity_type
        self.numHeartbeatLoss = 0
        self.secs_remain = 0
        cloud_platform = platform_in

        if not platform_in or platform_in is None:
            if is_aws_instance() or is_openstack_instance() or is_azure_instance() or is_nutanix_instance() or is_exsi_instance():
                logger.info('platform detected is {}'.format(cloud_platform))
            else:
                logger.info('platform argument is not supported.')
        else:
            platform = platform_in
        self.n_info = {}
        self.n_info['version'] = str(version)
        self.n_info['heartbeatFreqInSecs'] = 30
        self.n_info['entityType'] = str(entity_type)
        config_dir=''
        if str(entity_type) == 'vseriesNode':
            config_dir = '/home/gigamon'
        elif str(entity_type) == 'uctV' and get_instance_os() == 'Windows':
            config_dir = 'C:/ProgramData/uctv'
        else:
            config_dir = '/etc'
        self.node = NodeInfo(config_dir+'/gigamon-cloud.conf', self.n_info)
        self.reg_node = RegNode(self.node.node_info)

        # initially controller proxy drop all agent request on TCP port 8891,
        # once controller gets registered to FM, it starts to forward agent request.
        if entity_type == 'uctVController':
            cntlr_drop_agent_request_v6()
            cntlr_drop_agent_request()
            cntlrProxyForward = False

    def has_complete_user_config(self):
        global reg_data_template
        global is_ip_ver_mismatch
        if is_ip_ver_mismatch:
            logger.warning("IP version mismatch found between Source and Remote IP user config");
            return False
        if not self.reg_node or not self.reg_node.reg_info:
            return False
        for key in reg_config_template:
            if key == 'sourceIP':
                continue
            if not key in self.reg_node.reg_info:
                logger.warning("user-config: missing %s", key)
                return False
            val = self.reg_node.reg_info[key]
            if len(str(val)) == 0:
                logger.warning("user-config: empty %s", key)
                return False
            if key in ('ipv4Addresses','ipv6Addresses','remoteIP'):
                for ip in val:
                    if not is_valid_ipv6_addr(ip):
                        if not is_valid_ipv4_addr(ip):
                            logger.warning("user-config: invalid remote IP %s", val)
                            return False;
            else:
                pass
        return True

    def send_heartbeat(self):
        global maxHearbeatLoss
        global cntlrProxyForward
        sendData = ''
        base_url = '/api/v1.3/cloud/orchestration/%s/%s/heartbeat' %(self.entity_type, self.reg_node.reg_info['id'])
        status = True
        logger.info('PUT ' + self.reg_node.url + base_url)
        resp_code = 0
        resp_data = ''
        try:
            headers = { "Authorization": self.reg_node.reg_info['auth'] }
            r = requests.put(self.reg_node.url + base_url, verify = False, timeout = HTTP_TIMEOUT, headers = headers)
            resp_code = r.status_code
            resp_data = r.content
        except requests.exceptions.ConnectionError:
            logger.error("Connection error occurred.")
        except requests.exceptions.HTTPError:
            logger.error("HTTP error occurred.")
        except Exception as error:
            logger.error(str(error))
        finally:
            drop_it = False
            if resp_code == 404:
                logger.warning('[' + str(resp_code) + ']')
                status = False
                # 404 means being deregistered by FM, if not yet, controller shall start to drop all agent requests.
                drop_it = True
                self.numHeartbeatLoss = 0
            elif resp_code == 0:
                self.numHeartbeatLoss += 1
                if self.numHeartbeatLoss >= maxHeartbeatLoss:
                    drop_it = True
                self.reg_node.rotate_remote_ip()
            else:
                self.numHeartbeatLoss = 0
                logger.debug('[' + str(resp_code) + '] ' + str(resp_data))
                errorCode(resp_code, resp_data)

            # once controller registered, starts to forward agent request
            if self.entity_type == 'uctVController':
                if drop_it and cntlrProxyForward:
                    cntlr_drop_agent_request_v6()
                    cntlr_drop_agent_request()
                    cntlrProxyForward = False
                elif not drop_it and not cntlrProxyForward:
                    cntlr_forward_agent_request_v6()
                    cntlr_forward_agent_request()
                    cntlrProxyForward = True
                else:
                    pass

        return status

    def unregister(self):
        global cntlrProxyForward
        sendData = ''
        base_url = '/api/v1.3/cloud/orchestration/%s/%s/unregistration' %(self.entity_type, self.reg_node.reg_info['id'])
        status = False
        logger.info('DELETE ' + self.reg_node.url + base_url)
        resp_code = 0
        resp_data = ''
        try:
            headers = { "Authorization": self.reg_node.reg_info['auth'] }
            r = requests.delete(self.reg_node.url + base_url, verify = False, timeout = HTTP_TIMEOUT, headers = headers)
            resp_code = r.status_code
            resp_data = r.content
        except requests.exceptions.ConnectionError:
            logger.error("Connection error occurred.")
        except requests.exceptions.HTTPError:
            logger.error("HTTP error occurred.")
        except Exception as error:
            logger.error(str(error))
        finally:
            if resp_code == 204:
                logger.debug('[' + str(resp_code) + ']')
                status = True
            elif resp_code == 0:
                self.reg_node.rotate_remote_ip()
                pass
            else:
                logger.debug('[' + str(resp_code) + '] ' + str(resp_data))
                errorCode(resp_code, resp_data)

        if self.entity_type == 'uctVController':
            if cntlrProxyForward:
                cntlr_drop_agent_request_v6()
                cntlr_drop_agent_request()
                cntlrProxyForward = False

        return status

    def run(self, name):
        logger.info("Thread %s: starting. %s %s", name, self.version, self.entity_type)
        logger.info("Thread %s: running %s", name, "yes" if self.running else "no")

        while self.running:
            if self.reg_node.state == "unregistered":
                self.reg_node.Register()
                if self.reg_node.newHeartbeatFreq != None:
                    self.node.set_heartbeat_freq(self.reg_node.newHeartbeatFreq)
            elif self.reg_node.state == "registered":
                if self.send_heartbeat() == False:
                    self.reg_node.state = "unregistered"
                    logger.info("Thread %s: %s %s", name, self.version, self.entity_type)

            # split a big sleep to multiple sleep(1), so thread can be killed quicker
            tv = self.node.node_info['heartbeatFreqInSecs']
            tv = 4 if tv == 0 else tv

            while (tv > 0 and self.running):
                time.sleep(1)
                tv -= 1

        ## send de-registration to FM ##
        if self.reg_node.state == "registered":
            self.unregister()
        logger.info("Thread %s: stopped.", name)

    def win_reg_run_once(self):
        #logging.info("reg run once: secs_remain %d", self.secs_remain)
        if self.running:
            if self.secs_remain > 2:
                self.secs_remain -= 2
            else:
                #logging.info(" reg run once: state = %s", self.reg_node.state)
                if self.reg_node.state == "unregistered":
                    self.reg_node.Register()
                    if self.reg_node.newHeartbeatFreq != None:
                        self.node.set_heartbeat_freq(self.reg_node.newHeartbeatFreq)
                elif self.reg_node.state == "registered":
                    if self.send_heartbeat() == False:
                        self.reg_node.state = "unregistered"
                else:
                    pass

                self.secs_remain = self.node.node_info['heartbeatFreqInSecs']
                #logging.info("reg run once: secs_remain -> %d", self.secs_remain)
        else:
            if self.reg_node.state == "registered":
                self.unregister()

    def terminate(self):
        self.running = False

    def get_credentials():
        return self.n_info['user'], self.n_info['password']

