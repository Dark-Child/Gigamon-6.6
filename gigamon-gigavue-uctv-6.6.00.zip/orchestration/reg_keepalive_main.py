#! /usr/bin/python3.9

import threading
import os
import sys, getopt
import regheartbeat
import time
import logging
from logging.handlers import RotatingFileHandler

instance_reg = ''
logger = ''

def logging_init():
    global logger

    if regheartbeat.get_instance_os() == 'Windows':
        log_file = 'C:\\ProgramData\\uctv\\uctv-reg.log'
    else:
        log_file = '/var/log/uctv-reg.log'

    log_format = ('%(asctime)s %(levelname)s %(message)s')
    logging.basicConfig(
        level = logging.INFO,
        format = log_format,
        handlers = [RotatingFileHandler(log_file, maxBytes=2048000, backupCount=8)]
    )

    # initializing registration
    logger = logging.getLogger(__name__)
    logger.info("Logging initialized.")
    logger.info("Logging file for registration: %s.", log_file)

def win_reg_setup(cloud_type):
    import pyreadline
    global instance_reg
    global logger
    logging_init()
    argv = ['__main__', '-v', '6.6.00', '-t', 'uctV']
    argv.append('-p')
    argv.append(cloud_type)
    version, entity_type, platform = regheartbeat.main(argv[1:])
    logger.info("ver=%s type=%s platform=%s", version, entity_type, platform)

    r = regheartbeat.RegHeartBeat(version, entity_type, platform)
    logger.info("reg setup")

    if not r.has_complete_user_config():
        logger.info("There is no complete user configuration for orchestration.")
        logger.info("Registration process is not started.")
    else:
        instance_reg = r
        logger.info("reg setup complete")

def win_reg_run_once():
    global instance_reg
    #logging.info("reg run once.")
    if instance_reg:
        instance_reg.win_reg_run_once()
        #logging.info("reg run once complete.")

def win_reg_stop():
    global instance_reg
    global logger
    #logger.info("reg stop")
    if instance_reg:
        instance_reg.terminate()
        instance_reg.win_reg_run_once()
        #logger.info("reg stop completed.")

def main(argv):
    global logger
    logging_init()
    logger.info("reg_keepalive-main ...")

    version, entity_type, platform = regheartbeat.main(argv[1:])
    logger.info("reg_keepalive-main ver=%s type=%s platform=%s", version, entity_type, platform)

    r = regheartbeat.RegHeartBeat(version, entity_type, platform)
    logger.info("reg_keepalive-main ... r")

    if not r.has_complete_user_config():
        logger.info("There is no complete user configuration for orchestration.")
        logger.info("Registration process is not started.")
        exit(0)

    logger.info("reg_keepalive_main ... start thread")
    t = threading.Thread(target = r.run, args = ("registration_keepalive_thread", ))
    t.start()
    logger.info("reg_keepalive-main ... started")

    term = regheartbeat.CatchTerm()
    while not term.term_now:
        time.sleep(1)

    logger.info("reg_keepalive-main ... to terminate")
    r.terminate()
    t.join()
    logger.info("reg_keepalive-main ... terminated")

if __name__ == '__main__':
    main(sys.argv)
